﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2_2_1204020
{
    public class siang : Aktivitas
    {
        protected string kemampuan;

        public siang(string jenis, string kemampuan) : base(jenis, kemampuan)
        {


            this.Jenis = jenis;
            this.Nama = "geming";
            this.kemampuan = kemampuan;
        }

        public string Kemampuan
        {
            get
            {
                return kemampuan;
            }
            set
            {
                kemampuan = value;
            }
        }
    }
}
