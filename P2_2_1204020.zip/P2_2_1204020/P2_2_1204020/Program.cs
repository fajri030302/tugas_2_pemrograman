﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2_2_1204020
{
    public class Program
    {
        static void Main(string[] args)
        {


            siang aktivitas= new siang("tidur ", "adu mekanik");

            Console.WriteLine("kegiatan  {0} siang hingga menjelang magrib {1} malam {2}", aktivitas.Nama, aktivitas.Jenis, aktivitas.Kemampuan);
            Console.WriteLine();


        }
    }
}
